<?php
ob_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Admin account</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
	<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">
      <div class="row mt-5 pt-5 justify-content-center pl-1 pr-1">
        <h4 class="col-md-12" style="text-align: center;">Admin account<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
          
     <div class="m-0 pt-3 col-md-12 skin_plasma p-0" style="min-height:100vh;">
       <div class="row justify-content-center m-0 pt-3 col-md-12 ">
				            <div class="col-md-3 mr-lg-2 border-left border_set">
            
                <?php if(isset($_GET['note_admin_uptoken'])){?> 
                <div class="col-md-12 p-0 text-center mb-3">
                <div class="col-md-12 m-2"><b>User Pic</b></div>
                    <?php 
                          if($note_admin_node["user_pic"]!="") 
                            {
                              $file_type_image=magic_if_image($note_admin_node["user_pic"]);
                                if($file_type_image=='Yes')
                                {?>

                              <img src="<?php if($note_admin_node["user_pic"]=="") { echo $mep_app_logo;}else{ echo $note_admin_node["user_pic"];}?>" onclick="mosy_img_pop(this.src, 'max-width:100%; max-height:70vh');glass_modal()" class=" cpointer border border_set" style="width:200px; height:200px; border-radius:50%;"/>

                                <?php }else{
                                $actual_file_name=explode("/", $note_admin_node["user_pic"]);
                                echo '<a href="'.$note_admin_node["user_pic"].'" target="_blank" class=""><i class="fa fa-paperclip" style="font-size:70px;"></i> 
                                <br>'.end($actual_file_name).'<hr> <i class="fa fa-download"></i> Download</a>';
                                }
                            }else{?>

                             <img src="<?php if($note_admin_node["user_pic"]=="") { echo $mep_app_logo;}else{ echo $note_admin_node["user_pic"];}?>" onclick="magic_img_pop(this.src, 'max-width:100%; max-height:70vh');glass_modal()" class=" border border_set" style="width:200px; height:200px; border-radius:50%;"/>

                            <?php } ?>
                   
              <input type="file" name="txt_note_admin_user_pic" class="form-control mt-3">
              <input type="submit" name="btn_upload_note_admin_user_pic" class="btn btn-primary mt-2" value="Upload">
              <input type="hidden" name="txt_user_pic" value="<?php echo $note_admin_node["user_pic"];?>">
                </div> 
                <?php }?>
    
            </div>
            <div class="col-md-8 row justify-content-left m-0  p-0">
               
        <div class="form-group col-md-4">
          <label >Name</label>
          <input class="form-control" id="txt_name" name="txt_name" value="<?php echo $note_admin_node["name"];?>" placeholder="Name" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Email</label>
          <input class="form-control" id="txt_email" name="txt_email" value="<?php echo $note_admin_node["email"];?>" placeholder="Email" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Tel</label>
          <input class="form-control" id="txt_tel" name="txt_tel" value="<?php echo $note_admin_node["tel"];?>" placeholder="Tel" type="text">
        </div>

                 <div class="form-group col-md-4">
                   <label >Login Password</label>
                   <input class="form-control" id="txt_login_password" name="txt_login_password" value="<?php echo $note_admin_node["login_password"];?>" placeholder="Login Password" type="password">
                   <input type="checkbox"  onclick="show_password('txt_login_password')"> <span class=""><em>Show Password</em></span>
                  </div>
              

        <div class="form-group col-md-4">
          <label >Payment Reference No.</label>
          <input class="form-control" id="txt_ref_id" name="txt_ref_id" value="<?php echo $note_admin_node["ref_id"];?>" placeholder="Payment Reference No." type="text">
        </div>

         <div class="form-group col-md-4">
           <label >Date</label>
           <input class="form-control" id="txt_regdate" name="txt_regdate" value="<?php echo date_time_input($note_admin_node["regdate"], "full");?>" placeholder="Date" type="datetime-local">
         </div>

        <div class="form-group col-md-4">
          <label >User No</label>
          <input class="form-control" id="txt_user_no" name="txt_user_no" value="<?php echo $note_admin_node["user_no"];?>" placeholder="User No" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >User Gender</label>
          <input class="form-control" id="txt_user_gender" name="txt_user_gender" value="<?php echo $note_admin_node["user_gender"];?>" placeholder="User Gender" type="text">
        </div>

         <div class="form-group col-md-4">
           <label >Last Seen</label>
           <input class="form-control" id="txt_last_seen" name="txt_last_seen" value="<?php echo date_time_input($note_admin_node["last_seen"], "full");?>" placeholder="Last Seen" type="datetime-local">
         </div>

            <div class="form-group col-md-12">
              <label >About</label>
              <textarea class="form-control" id="txt_about" name="txt_about" placeholder="About" style="min-height:200px;"><?php echo $note_admin_node["about"];?></textarea>
            </div>

               
      <div class="col-md-12 text-center">
      <?php if(!isset($_GET['note_admin_uptoken'])){?> 
            <button type="submit" id="note_admin_insert_btn" name="note_admin_insert_btn" class="btn btn-primary" > 
              <i class="fa fa-check"></i> Proceed 
            </button>
            <?php } ?>
      <?php if(isset($_GET['note_admin_uptoken'])) {?>
            <button type="submit" id="note_admin_update_btn" name="note_admin_update_btn" class="btn btn-primary" > 
              <i class="fa fa-save"></i> Save Changes 
            </button>
            <button type="submit" id="note_admin_insert_btn" name="note_admin_insert_btn" class="btn btn-primary" > 
              <i class="fa fa-copy"></i> Clone Record 
            </button>          
            <?php } ?>
    </div>
  
            </div>
          </div>
          <div class="row justify-content-center m-0 p-0 col-md-12 mt-3">
                            <!-- Start  Title ribbon-->
                  <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                    <div class="col-md-3 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                    <div class="col-md-5 text-center"> More Note Admin</div>
                    <div class="col-md-4 bg-dark mt-3" style="height: 1px"></div>
                  </h5>
                  <div class="row justify-content-left col-md-12 mt-3">

                    <input type="text" class="col-md-2 mb-2 ml-2 bg-transparent" placeholder="Search Note Admin" name="txt_note_admin" style="color:<?php echo $body_txt ?>; border:none; border-bottom:1px solid <?php echo $btn_bg ?>;"/>
                         <button type="submit" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2" name="qnote_admin_btn"><i class="fa fa-search"></i> Go</button>                  
                    </div>
     
                  <!-- End Title ribbon-->
          <?php include("./data_ui/note_admin_list_wgt.php");?>
          
          </div>
      </div>
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>