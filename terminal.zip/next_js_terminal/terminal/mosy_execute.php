<?php 	ui_write_to_file('../dreamchat.zip', file_get_contents('https://github.com/Asanetic/phpmagicbits/raw/master/uitemplates/simpleui.zip?raw=true'));
?>