//dna options==
$dna_file_name="next_js_profile_builder_"; 
$create_dna="yes"; //yes | no; 
$overwrite_dna_file="yes"; //yes | no 
//dna options==

eval(find_snippet('1174'));

foreach ($db_tables_list as $tableName => $columns) 
{
  if(isset($widget_and_ist_array[$tableName])){

      $curr_tbl= $tableName;

      $js_component_nodes_str=array();
      $magic_where_str=array();
      $tbl_key_arr=array();
      $tbl_head="";
      $tbl_row="";

      $col_count=0;


    
    //============================================================= Rename Table 
    $table_rename=ucwords(strtolower(str_replace("_", " ", $curr_tbl)));

    $table_icon=$default_icon;
    if(isset($rename_tables_array[$curr_tbl]))
    {
      $table_ren_attr=explode(":", $rename_tables_array[$curr_tbl]);
      $table_rename=$table_ren_attr[0];
      if(isset($table_ren_attr[1]))
      {
       $table_icon=$table_ren_attr[1];
      }
    }

    
    //============================================================= Rename Table 
    /////// === add link to navbar  
    $pgtitle= $main_report_title_;
      

     $prof_page_title='{'.$primary_table__.'Node?.'.$tbl_id_column_name.' ? (  <span>'.$pgtitle.' Profile</span>) : (<span>Add '.$table_rename.'</span>)}';

      /////// === add link to navbar  
            $new_btn_icon="plus-circle";
            $new_btn_name=" Add new"; 
            $page_title_w_data="$pgtitle Profile";
          if(isset($new_label_buttons_arr[$curr_tbl]))
          {
            $new_btn_label_arr=explode(":", $new_label_buttons_arr[$curr_tbl]);
            $new_btn_icon=$new_btn_label_arr[0];
            $new_btn_name=$new_btn_label_arr[1];
            if(isset($new_btn_label_arr[2]))
            {
             $new_profile_page_title_pattern = '/\{\{(\w+)\}\}/';
             $new_profile_page_title_replacement = '{'.$curr_tbl.'Node?.$1 || ""}';

             $page_title_w_data = preg_replace($new_profile_page_title_pattern, $new_profile_page_title_replacement, $new_btn_label_arr[2]);
                       
            }
            

            $prof_page_title='{'.$primary_table__.'Node?.'.$tbl_id_column_name.' ? (  <span>'.$page_title_w_data.'</span> ) :(<span> '.$new_btn_name.'</span>)}';
            
          }

      foreach ($columns as $column) 
      {
        $col_count++;      

        $columnName = $column['name'];

        $tbl_key_arr=$columns;

        $tbl_primkey=$tbl_key_arr[0]['name'];

       
        eval(find_snippet('1175'));

        
        //eval(find_snippet('925'));

      }   
    
  }
  

$profile_action_buttons__="";

foreach($profile_btn_table_array as $table_node => $attr)
{

  foreach($attr as $table_attr => $button_function_)
  {
    
    $button_components = explode(":", $table_attr);
    $button_icon=$button_components[0];
    $button_label=$button_components[1];
    

    $profile_action_buttons__ .= '    
    <MosyActionButton 
      label="'.$button_label.'"  
      icon="'.$button_icon.'" 
      onClick={()=>{'.$button_function_.'}}
    />
    ';

    
  }
  
}
  

  $delete_btn_='
  <DeleteButton
  src="'.$camelcasetbl_prefix.'MainProfilePage"
  tableName="'.$curr_tbl.'"
  uptoken={param'.$camelcasetbl_prefix.'Uptoken}
  stateItemSetters={stateItemSetters}
  parentStateSetters={parentStateSetters}
  router={router}
  onDelete={popDeleteDialog}
  />
  ';
  
    $add_new_btn='

   {param'.$camelcasetbl_prefix.'Uptoken && ( 
     <>
      '.$profile_action_buttons__.'   
     </>
   )}
   
      {param'.$camelcasetbl_prefix.'Uptoken && showNavigationIsle && (
       <>
      '.$delete_btn_.'

      <AddNewButton      
      src="'.$camelcasetbl_prefix.'MainProfilePage"
      tableName="'.$curr_tbl.'"
      link="./'.$profile_file_name.'" 
      label="'.$new_btn_name.'" 
      icon="'.$new_btn_icon.'" />
      </>
      )}'; 


     $ui_card_title='
  {/*    Title isle      */}
  <div className="col-md-12 pt-4 p-0 hive_profile_title_top d-lg-none" id=""></div>
  <h3 className="col-md-12 title_text text-left p-0 pt-3 hive_profile_title row justify-content-center m-0 ">
   <div className="col m-0 p-0 pb-3"> 
    '.$prof_page_title.'
   </div>
   <>{!showNavigationIsle && (<div className="col m-0 p-0 text-right "> 
        {param'.$camelcasetbl_prefix.'Uptoken && ( '.str_replace("router={router}","",$delete_btn_).')}
   </div>)}</>
 </h3>
  {/*    Title isle      */}

             ';

     $ui_card_navigation=' 
  {/*    Navigation isle      */}
   <><div className="row justify-content-end m-0 p-0 col-md-12  p-3 bg-white hive_profile_navigation " id="">
    <div className="col-md-4 text-left p-0 hive_profile_nav_back_to_list_tray" id="">

     {showNavigationIsle && ( <Link href="'.$back_to_list_.'" className="text-info hive_profile_nav_back_to_list"><i className="fa fa-arrow-left"></i> Back to list</Link>)}

    </div>
    <div className="col-md-8 p-0 text-right hive_profile_nav_add_new_tray" id="">   
     
     '.$add_new_btn.' 

    </div>              
  </div></>               
  <div className="col-md-12 pt-4 p-0 hive_profile_navigation_divider d-lg-none" id=""></div>
   {/*    Navigation isle      */}';

$footer_and_mini_list='
  <div className="row justify-content-center m-0 pr-lg-1 pl-lg-1 pt-0 col-md-12" id="">           
  {/*<hive_mini_list/>*/}    
   '.$final_subprofile_str.'
  '.$final_mini_str.'
  </div>';
  
  
            $mainpage_content_='

  
  <div className="'.$col_size_def.' row justify-content-center m-0  p-0">
    {/*    Input cells section isle      */}
    '.$element_cell_sections.'
    {/*    Input cells section isle      */}
  </div>
  
  <section className="hive_control">  
    <input type="hidden" id="'.$curr_tbl.'_uptoken" name="'.$curr_tbl.'_uptoken" value={param'.$camelcasetbl_prefix.'Uptoken}/>
    <input type="hidden" id="'.$curr_tbl.'_mosy_action" name="'.$curr_tbl.'_mosy_action" value={'.$camelcasetbl.'ActionStatus}/>
  </section>
                           
            ';
  
              $final_profile_rendering='
<div className="'.$def_profile_container_class.'">                         
   <div className={'.$def_profile_inner_container_class.'}>  
      <form onSubmit={post'.$camelcasetbl_prefix.'FormData} encType="multipart/form-data" id="'.$curr_tbl.'_profile_form">
        '.$ui_card_title.'                              
         '.$ui_card_navigation.'                             
        <div className="row justify-content-center m-0 p-0 col-md-12" id="">
          {/*    Image section isle      */}
             '.$img_tray.'
          {/*    Image section isle      */}

          {/*  //-------------    main content starts here  ------------------------------ */}
          '.$mainpage_content_.'
        </div>

       </form>

       '.$footer_and_mini_list.'                         
    </div>                     
</div>';
  
  if(isset($next_js_custom_profile_card[$curr_tbl]))
  {
    $replacements = [
  '{{navigationIsle}}' => "{<div className='row justify-content-center col-md-12 m-0 p-0'>".$ui_card_navigation."</div>}",
  '{{profileTitle}}' => "{<div className='row justify-content-center col-md-12 m-0 p-0'>".$ui_card_title."</div>}",
  '{{profilePic}}' => $final_image_node,
  '{{profileUploadBtn}}' => "{<div className='row justify-content-center col-md-12 m-0 p-0'>".$upload_btn."</div>}",
  '{{mainContent}}' => "{<div className='row justify-content-center col-md-12 m-0 p-0'>".$mainpage_content_."</div>}",
    ];

   $additional_imports.="import {".$next_js_custom_profile_card[$curr_tbl]["card_name"]."} from '../../../components/ProfileLayout'\n";
    
   $custom_profile_card_str = str_replace(array_keys($replacements), array_values($replacements), $next_js_custom_profile_card[$curr_tbl]["layout_tag"]);
    
              $final_profile_rendering='
   <div className={'.$def_profile_inner_container_class.'}>  
     <form onSubmit={post'.$camelcasetbl_prefix.'FormData} encType="multipart/form-data" id="'.$curr_tbl.'_profile_form">
                           
       <div className="row justify-content-center m-0 p-0 col-md-12" id="">
       '.$custom_profile_card_str.'
       </div>
    </form>
     '.$footer_and_mini_list.'                              
  </div>
 
 ';
    
  }
  
     $profile_ui='\'use client\';

//React
import { useEffect, useState } from \'react\';

import Link from \'next/link\';

import { useRouter } from \'next/navigation\';

'.$additional_imports.'

export default function '.$camelcasetbl_prefix.'Profile({ dataIn = {}, dataOut = {} }) {

  //initiate data exchange manifest
  //incoming data from parent
  const {
    showNavigationIsle = true,
    customQueryStr = "",
    parentUseEffectKey = "",
    parentStateSetters=null,
    customProfileData={},
    hostParent="'.$camelcasetbl_prefix.'MainProfilePage"
  } = dataIn;

  //outgoing data to parent 
  const {
    setChildDataOut = () => {},
    setChildDataOutSignature = () => {},
  } = dataOut;
  
  
   //set default state values
   const settersOverrides  = {localEventSignature : parentUseEffectKey}

   //manage '.$camelcasetbl_prefix.' states
   const [stateItem, stateItemSetters] = use'.$camelcasetbl_prefix.'State(settersOverrides);
   const '.$curr_tbl.'Node = stateItem.'.$camelcasetbl.'Node
   
   // -- basic states --//
   const param'.$camelcasetbl_prefix.'Uptoken  = stateItem.'.$camelcasetbl.'Uptoken
   const '.$camelcasetbl.'ActionStatus = stateItem.'.$camelcasetbl.'ActionStatus
   const snackMessage = stateItem.snackMessage
   //const snackOnDone = stateItem.snackOnDone

  const localEventSignature = stateItem.localEventSignature
  
   const handleInputChange = mosyFormInputHandler(stateItemSetters.set'.$camelcasetbl_prefix.'Node);

  //use route navigation system
  const router = useRouter();
  
  //manage post form
  function post'.$camelcasetbl_prefix.'FormData(e) {

    MosyNotify({message: "Sending request",icon:"send"})
    
    inteprate'.$camelcasetbl_prefix.'FormAction(e, stateItemSetters).then(response=>{
      
      setChildDataOut({

        actionName : response.actionName,
        dataToken : response.newToken,
        actionsSource : "post'.$camelcasetbl_prefix.'FormData",
        setters :{
                            
         childStateSetters: stateItemSetters,              
         parentStateSetters: parentStateSetters
              
       }

      })

      mosyScrollTo("'.$camelcasetbl_prefix.'ProfileTray")
      closeMosyModal()
      
    })
    
  }

  useEffect(() => {
        
    '.$camelcasetbl.'ProfileData(customQueryStr, stateItemSetters, router, customProfileData)
    
      mosyScrollTo("'.$camelcasetbl_prefix.'ProfileTray")
        
    
  }, [localEventSignature]);
  
  
  
  //child queries use effect
  '.$profile_component_query_script_.'
  
  
  return (    
 
     <div className="p-0 col-md-12 text-center row justify-content-center m-0  " id="'.$camelcasetbl_prefix.'ProfileTray">
       {/* ================== Start Feature Section========================== ------*/}
       
        '.$final_profile_rendering.'

       
        {/* snack notifications -- */}
        {snackMessage &&(
          <MosySnackWidget
          content={snackMessage}
          duration={5000}
          type="custom"
          onDone={() => {
            stateItemSetters.setSnackMessage("");
            stateItem.snackOnDone(); // Run whats inside onDone
            deleteUrlParam("snack_alert")
          }}
          
          />)}
          {/* snack notifications -- */}   
          
            
       {/* ================== End Feature Section========================== ------*/}
     </div>

     );
     
     }
    ';


    $profile_page_js_str='import { Suspense } from \'react\';

import '.$camelcasetbl_prefix.'Profile from \'../uiControl/'.$camelcasetbl_prefix.'Profile\';

import { Inteprate'.$camelcasetbl_prefix.'Event } from \'../dataControl/'.$camelcasetbl_prefix.'RequestHandler\';

    
export async function generateMetadata({ searchParams }) {
  const mosyTitle = "'.$pgtitle.' profile"//searchParams?.mosyTitle || "'.$pgtitle.'";

  return {
    title: mosyTitle ? decodeURIComponent(mosyTitle) : `'.$pgtitle.' profile`,
    description: \''.$appname. ' ' .$pgtitle.'\',
    
    icons: {
      icon: "/logo.png"
    },    
  };
}
                      

export default function '.$camelcasetbl_prefix.'MainProfilePage() {

   return (
     <>
       <div className="main-wrapper">
          <div className="page-wrapper">
             <div className="content container-fluid p-0 m-0 ">
               <Suspense fallback={<div className="col-md-12 p-5 text-center h3">Loading...</div>}>
                 <'.$camelcasetbl_prefix.'Profile 
                    dataIn={{ parentUseEffectKey: "init'.$camelcasetbl_prefix.'Profile" }} 
                                           
                    dataOut={{
                       setChildDataOut: Inteprate'.$camelcasetbl_prefix.'Event
                    }}   
                    
                 />
               </Suspense>
             </div>
           </div>
         </div>
       </>
     );
}'; 
  
    $main_page_profile_folder=$features_app_folder."/".$nextjs_tbl_alias."/".$profile_file_name."";

    $profile_page_jsx_folder=$features_app_folder."/".$nextjs_tbl_alias;
    $profile_uicontrol_folder_=$profile_page_jsx_folder."/uiControl"; 

  
    if (!file_exists($main_page_profile_folder)) mkdir($main_page_profile_folder, 0777, true);
    
    if (!file_exists($profile_uicontrol_folder_)) mkdir($profile_uicontrol_folder_, 0777, true);
 
      $profile_uicontrol_widget_ = $profile_uicontrol_folder_.'/'.$camelcasetbl_prefix.'Profile.jsx';
  
      $main_profile_page_jsx=$main_page_profile_folder."/page.jsx";  

      Recycle($main_profile_page_jsx);

      magic_write_to_file($main_profile_page_jsx, $profile_page_js_str); 
      
      
      Recycle($profile_uicontrol_widget_);

      $formatted_ui = beautifyJSX($profile_ui);

      magic_write_to_file($profile_uicontrol_widget_, $formatted_ui);       

  
  echo '<h3>Profile component created at <a href="http://localhost:3000/'.$appname.'/'.$nextjs_tbl_alias.'/'.$profile_file_name.'" target="_blank">Open /'.$nextjs_tbl_alias.'/'.$profile_file_name.'</a></h3>';
  
    //========================= profile ui 
}   